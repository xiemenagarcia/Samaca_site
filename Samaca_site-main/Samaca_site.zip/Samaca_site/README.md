La estructura del taller consta de una landing page (`index.html`) y cuatro subpáginas sobre una cátegoria del pueblo (gastronomia, turismo, festividades, historia).
